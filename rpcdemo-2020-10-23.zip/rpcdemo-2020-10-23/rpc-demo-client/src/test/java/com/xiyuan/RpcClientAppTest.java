package com.xiyuan;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Unit test for simple RpcClientApp.
 */
public class RpcClientAppTest
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
}
